
//code attribute
//Govender, D. 2024. PROG6211 ASSIGNMENT SUPPORT
//[Offline] 
//[accessed 1 september 2024] 
package com.mycompany.businessidea;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class BusinessIdea {

  // declaring components that im going to be using throut the application
    private ArrayList<Idea>Complaints;
    private Scanner scanner; 


    public BusinessIdea() {
        Complaints = new ArrayList<>(); 
        scanner = new Scanner(System.in); 
    }
  //methoud that saves Customers info
    public void saveComplaint() {
        //code that asks the user to enter information about the themselves and their complaints
        scanner.nextLine(); 
        System.out.print("Enter your name: ");
        String CustomerName = scanner.nextLine();
        System.out.print("Enter the name of the agent helping you: ");
        String CustomerAgent = scanner.nextLine();
        System.out.print("Enter your Complaint and suggestion: ");
        String CustomerComplaint = scanner.nextLine();
        

       
            
        
// adds latest details about Customers to the array list 
        Idea newIdea = new Idea(CustomerName,CustomerComplaint,CustomerAgent);
        Complaints.add(newIdea);
        //code that outputs success message about saving Customers details
        System.out.println("Student saved successfully.");
    }
    // adds latest details about Customers to the array list 
      public void saveComplaint(String CustomerName, String CustomerComplaint, String CustomerAgent ) {
        Idea newIdea = new Idea(CustomerName,CustomerComplaint,CustomerAgent);
        Complaints.add(newIdea);
        System.out.println("Complaint saved successfully.");
    }
//scanner.hasNextInt
    
    //method that uses agent name to serch if any complainst against them were issued
    public Idea searchAgent(String productId) {
        for (Idea product : Complaints) {
            if (product.getCustomerAgent().equalsIgnoreCase(productId)) {
                return product;  
            }
        }//code that returns nothing if agent name  has not been found in the arraylist
        return null; 
    }

 
   

//method that displays all the Customer details that have been entered and are saved on the arraylist
    public void printComplaintsReport() {
        if (Complaints.isEmpty()) {
            System.out.println("No Complaints available.");
        } else {
            System.out.println("\nComplaint List:");
            for (Idea product : Complaints) {
                System.out.println(product);
            }
        }
    }

    //method that outputs message and exits program
    public void exitApplication() {
        System.out.println("Exiting application. Goodbye!");
    }


    public ArrayList<Idea> getProducts() {
        return Complaints;
    }

//method that launches menu for the user to interact with
    public void launchMenu() {
       
 //loop that launches menu and allows user to select which option number they want to do and according to their option number a certain method will be called to execute required task        
        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Save a new complaint");
            System.out.println("2. Search for a complaimt by agent");
            System.out.println("3. Print complaiint list");
            System.out.println("4. Exit application");
            System.out.print("Enter your choice: ");
            
            int choice;
            try {
                choice = scanner.nextInt();
                //code that breaks application incase user entered incorrect input
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Exiting application.");
                break;
            }
//case statements to call methods based on what the user chose
            switch (choice) {
                case 1:
                    saveComplaint(); 
                    break;
                case 2:
                    scanner.nextLine(); 
                    System.out.print("Enter agent name to search: ");
                    String searchId = scanner.nextLine();
                    Idea foundProduct = searchAgent(searchId);
                    if (foundProduct != null) {
                        System.out.println("Complaint found: " + foundProduct);
                    } else {
                        System.out.println("Complaint not found.");
                    }
                    break;
                case 3:
                                       printComplaintsReport();
                    break;
                case 4:
                   exitApplication(); 
                
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 4.");
            }
        }
    }


    public static void main(String[] args) {
        BusinessIdea manager = new BusinessIdea();
        System.out.print("Press 1 to launch menu, any other key to exit: ");
        Scanner input = new Scanner(System.in);
        String choice = input.nextLine();

        if (choice.equals("1")) {
            manager.launchMenu();
        } else {
            System.out.println("Exiting application. Goodbye!");
        }
    }
}


   
