//code attribute
//Govender, D. 2024. PROG6211 ASSIGNMENT SUPPORT
//[Offline] 
//[accessed 1 september 2024] 
package com.mycompany.businessidea;


public class Idea {
    //all variables that will be used through out the program have been decalred
   private String CustomerName;
    private String CustomerComplaint;
   private String CustomerAgent;

    public Idea(String CustomerName, String CustomerComplaint,     String CustomerAgent) {
        this.CustomerName = CustomerName;
        this.CustomerComplaint = CustomerComplaint;
        this.CustomerAgent = CustomerAgent;
       
    }

  //method to either return certain variable or to assiociate a certain variable with another variable
    public String getCustomerName() {
        return CustomerName;
    }

    public void setCustomerName(String CustomerName) {
        this.CustomerName = CustomerName;
    }
    


    public String getCustomerComplaint() {
        return CustomerComplaint;
    }

    public void setCustomerComplaint(String CustomerComplaint) {
        this.CustomerComplaint = CustomerComplaint;
    }

    public String getCustomerAgent() {
        return CustomerAgent;
    }

    public void setCustomerAgent(String CustomerAgent) {
        this.CustomerAgent = CustomerAgent;
    }
   
    

    @Override
    //tostring method 
    public String toString() {
        return "Customer Agent: " + CustomerAgent + ", Name: " + CustomerName+ ", Complaint: " + CustomerComplaint;
    }
}

 

 

