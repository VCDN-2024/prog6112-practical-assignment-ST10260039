//code attribute
//Govender, D. 2024. PROG6211 ASSIGNMENT SUPPORT
//[Offline] 
//[accessed 1 september 2024] 

import com.mycompany.businessidea.BusinessIdea;
import com.mycompany.businessidea.Idea;
import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class IdeaTest {
    private BusinessIdea businessIdea;

    @Before
    public void setUp() {
        
        businessIdea = new BusinessIdea();
    }

    @Test
    public void testCustomerSaved() {
        businessIdea.saveComplaint("Veoin", "Nikhil", "Poor service");
        ArrayList<Idea> products = businessIdea.getProducts();
        assertEquals("Veolin", products.get(0).getCustomerName());
        assertEquals("Nikhil", products.get(0).getCustomerAgent());
        assertEquals("Poor service", products.get(0).getCustomerComplaint());
    }

    @Test
    public void testAgentSearch() {
        businessIdea.saveComplaint("Veolin", "Nikhil", "Poor service");    
        Idea foundProduct = businessIdea.searchAgent("Nikhil");
        asserIdeatEquals("Veolin", foundProduct.getCustomerName());
        assertEquals("Nikhil", foundProduct.getCustomerAgent());
        assertEquals("Poor service", foundProduct.getCustomerComplaint());
    }

    @Test
    public void testAgentNotFound() {
    Idea foundProduct = businessIdea.searchAgent("Katelyn");
    assertNull(foundProduct);
    }

    
}


   